﻿using System;
using System.Configuration;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.IO;

namespace AdoNetLab2
{
    class Program
    {
        static string ConnStr => ConfigurationManager.ConnectionStrings["MyConnString"].ConnectionString;

        static void Main()
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            Zapusk("zad1", zad1);
            Zapusk("zad2", zad2);
            Zapusk("zad3", zad3);
            Zapusk("zad3 problem", zad3Problem);
            Zapusk("zad4", zad4);
            Zapusk("zad5", zad5);
            Zapusk("zad6", zad6);
            Zapusk("zad7", zad7);
            Console.WriteLine("\nGotovo. Nazhmite lyubuyu klavishu...");
            Console.ReadLine();
        }

        static void Zapusk(string name, Action f)
        {
            Console.WriteLine("\n===== " + name + " =====");
            try { f(); }
            catch (Exception ex)
            {
                Console.WriteLine("Oshibka: " + ex.GetType().Name);
                Console.WriteLine(ex.Message);
            }
        }

        static void Pechat(DataTable t, string title)
        {
            Console.WriteLine("\n--- " + title + " ---");
            foreach (DataColumn c in t.Columns) Console.Write(c.ColumnName.PadRight(15));
            Console.WriteLine();
            Console.WriteLine(new string('-', t.Columns.Count * 15));
            foreach (DataRow r in t.Rows)
            {
                foreach (DataColumn c in t.Columns)
                {
                    object v = r.RowState == DataRowState.Deleted ? r[c, DataRowVersion.Original] : r[c];
                    Console.Write((v == DBNull.Value ? "NULL" : v.ToString()).PadRight(15));
                }
                Console.WriteLine();
            }
        }

        static void zad1()
        {
            DataTable t = new DataTable("Authors");
            t.Columns.Add("Id", typeof(int));
            t.Columns.Add("FirstName", typeof(string));
            t.Columns.Add("LastName", typeof(string));
            t.Rows.Add(1, "Isaac", "Asimov");
            t.Rows.Add(2, "Ray", "Bradbury");
            t.Rows.Add(3, "Clifford", "Simak");
            t.Rows.Add(4, "Roger", "Zelazny");
            Console.WriteLine("row[0] = " + t.Rows[0][0]);
            Console.WriteLine("row[FirstName] = " + t.Rows[0]["FirstName"]);
            Pechat(t, "Authors (manual)");
        }

        static void zad2()
        {
            using (SqlConnection c = new SqlConnection(ConnStr))
            {
                SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Authors", c);
                DataSet ds = new DataSet();
                da.Fill(ds, "Authors");
                Console.WriteLine("Sostoyanie soedineniya posle Fill: " + c.State);
                Pechat(ds.Tables["Authors"], "Authors from DB");
            }
            using (SqlConnection c = new SqlConnection(ConnStr))
            {
                SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Authors; SELECT * FROM Books;", c);
                DataSet ds = new DataSet();
                da.Fill(ds);
                Console.WriteLine("Tablitsy v DataSet:");
                foreach (DataTable t in ds.Tables) Console.WriteLine("  - " + t.TableName);
                Pechat(ds.Tables[0], "Authors");
                Pechat(ds.Tables[1], "Books");
            }
        }

        static void zad3()
        {
            using (SqlConnection c = new SqlConnection(ConnStr))
            {
                SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Books", c);
                SqlCommandBuilder cb = new SqlCommandBuilder(da);
                DataSet ds = new DataSet();
                da.Fill(ds, "Books");
                DataTable b = ds.Tables["Books"];
                Pechat(b, "Books before change");
                if (b.Rows.Count == 0) { Console.WriteLine("Net strok v Books"); return; }
                b.Rows[0]["Price"] = 999;
                Pechat(b, "Books after change");
                Console.WriteLine("INSERT: " + cb.GetInsertCommand().CommandText);
                Console.WriteLine("UPDATE: " + cb.GetUpdateCommand().CommandText);
                Console.WriteLine("DELETE: " + cb.GetDeleteCommand().CommandText);
                Console.WriteLine("Updated rows: " + da.Update(ds, "Books"));
                DataSet ds2 = new DataSet();
                da.Fill(ds2, "Books");
                Pechat(ds2.Tables["Books"], "Books after reload");
            }
        }

        static void zad3Problem()
        {
            using (SqlConnection c = new SqlConnection(ConnStr))
            {
                SqlDataAdapter da = new SqlDataAdapter("SELECT Title, Price, Pages FROM Books", c);
                SqlCommandBuilder cb = new SqlCommandBuilder(da);
                DataSet ds = new DataSet();
                da.Fill(ds, "Books");
                if (ds.Tables["Books"].Rows.Count > 0) ds.Tables["Books"].Rows[0]["Price"] = 123;
                try { da.Update(ds, "Books"); Console.WriteLine("Update vypolnilsya"); }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.GetType().Name);
                    Console.WriteLine(ex.Message);
                }
            }
        }

        static void zad4()
        {
            using (SqlConnection c = new SqlConnection(ConnStr))
            {
                SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Books", c);
                SqlCommand upd = new SqlCommand("UPDATE Books SET Price = @pPrice WHERE Id = @pId", c);
                upd.Parameters.Add(new SqlParameter("@pPrice", SqlDbType.Int));
                upd.Parameters["@pPrice"].SourceVersion = DataRowVersion.Current;
                upd.Parameters["@pPrice"].SourceColumn = "Price";
                upd.Parameters.Add(new SqlParameter("@pId", SqlDbType.Int));
                upd.Parameters["@pId"].SourceVersion = DataRowVersion.Original;
                upd.Parameters["@pId"].SourceColumn = "Id";
                da.UpdateCommand = upd;
                DataSet ds = new DataSet();
                da.Fill(ds, "Books");
                DataTable b = ds.Tables["Books"];
                if (b.Rows.Count < 2) { Console.WriteLine("Nuzhno 2 stroki"); return; }
                Pechat(b, "Books before changes");
                b.Rows[0]["Price"] = 111;
                b.Rows[1]["Price"] = 222;
                Pechat(b, "Books after changes");
                Console.WriteLine("Updated rows: " + da.Update(ds, "Books"));
                DataSet ds2 = new DataSet();
                da.Fill(ds2, "Books");
                Pechat(ds2.Tables["Books"], "Books after reload");
            }
        }

        static void zad5()
        {
            using (SqlConnection c = new SqlConnection(ConnStr))
            {
                SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Books", c);
                SqlCommandBuilder cb = new SqlCommandBuilder(da);
                DataSet ds = new DataSet();
                da.Fill(ds, "Books");
                DataTable b = ds.Tables["Books"];
                if (b.Rows.Count < 2) { Console.WriteLine("Nuzhno 2 stroki"); return; }
                Pechat(b, "Books before");
                b.Rows[0].Delete();
                b.Rows[1]["Price"] = 777;
                DataRow nr = b.NewRow();
                nr["AuthorId"] = 1;
                nr["Title"] = "New Book";
                nr["Price"] = 500;
                nr["Pages"] = 100;
                b.Rows.Add(nr);
                Pechat(b, "Books after local changes");
                Console.WriteLine("RowState:");
                foreach (DataRow r in b.Rows)
                {
                    string t = r.RowState == DataRowState.Deleted ? r["Title", DataRowVersion.Original].ToString() : r["Title"].ToString();
                    Console.WriteLine("  " + t.PadRight(20) + " -> " + r.RowState);
                }
                int d = da.Update(b.Select(null, null, DataViewRowState.Deleted));
                int u = da.Update(b.Select(null, null, DataViewRowState.ModifiedCurrent));
                int a = da.Update(b.Select(null, null, DataViewRowState.Added));
                Console.WriteLine("Deleted: " + d + ", Updated: " + u + ", Added: " + a);
                DataSet ds2 = new DataSet();
                da.Fill(ds2, "Books");
                Pechat(ds2.Tables["Books"], "Books after reload");
            }
        }

        static void zad6()
        {
            string sql = "SELECT * FROM Authors; SELECT * FROM Books;";
            Console.WriteLine("Bez TableMappings:");
            using (SqlConnection c = new SqlConnection(ConnStr))
            {
                SqlDataAdapter da = new SqlDataAdapter(sql, c);
                DataSet ds = new DataSet();
                da.Fill(ds);
                foreach (DataTable t in ds.Tables) Console.WriteLine("  - " + t.TableName);
                Pechat(ds.Tables[0], "Tables[0]");
                Pechat(ds.Tables[1], "Tables[1]");
            }
            Console.WriteLine("\nS TableMappings:");
            using (SqlConnection c = new SqlConnection(ConnStr))
            {
                SqlDataAdapter da = new SqlDataAdapter(sql, c);
                DataTableMapping am = da.TableMappings.Add("Table", "Authors");
                am.ColumnMappings.Add("Id", "Num");
                am.ColumnMappings.Add("FirstName", "Name");
                am.ColumnMappings.Add("LastName", "Surname");
                da.TableMappings.Add("Table1", "Books");
                DataSet ds = new DataSet();
                da.Fill(ds);
                foreach (DataTable t in ds.Tables) Console.WriteLine("  - " + t.TableName);
                Pechat(ds.Tables["Authors"], "Authors");
                Pechat(ds.Tables["Books"], "Books");
            }
        }

        static void zad7()
        {
            using (SqlConnection c = new SqlConnection(ConnStr))
            {
                SqlDataAdapter da = new SqlDataAdapter("SELECT Id, Name, Picture FROM Pictures WHERE Id = @id", c);
                da.SelectCommand.Parameters.Add("@id", SqlDbType.Int).Value = 1;
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count == 0) { Console.WriteLine("Kartinka s Id=1 ne naidena"); return; }
                DataRow r = ds.Tables[0].Rows[0];
                object p = r["Picture"];
                if (p == DBNull.Value) { Console.WriteLine("Picture = NULL"); return; }
                byte[] bytes = (byte[])p;
                File.WriteAllBytes("out.jpg", bytes);
                Console.WriteLine("Id:     " + r["Id"]);
                Console.WriteLine("Name:   " + r["Name"]);
                Console.WriteLine("Razmer: " + bytes.Length + " b");
                Console.WriteLine("Fayl:   " + Path.GetFullPath("out.jpg"));
            }
        }
    }
}